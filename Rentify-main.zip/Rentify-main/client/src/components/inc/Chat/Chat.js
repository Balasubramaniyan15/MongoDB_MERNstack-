import TawkMessengerReact from '@tawk.to/tawk-messenger-react';

function Chat() {
    return (
        <div className="Chat">
            <TawkMessengerReact
            propertyId="6437973f4247f20fefeb596a"
            widgetId="1gtsidjvt"/>
        </div>
    );
}

export default Chat

