import React from "react";
function Footer() {
    return (
      <footer>
        <p>Copyright © 2023</p>
      </footer>
    );
  }
  
  export default Footer;